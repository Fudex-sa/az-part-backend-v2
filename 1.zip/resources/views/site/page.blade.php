@extends('site.app')

@section('title') {{ $item['title_'.my_lang()] }} @endsection

@section('styles')
    
@endsection

@section('content')


@endsection