<?php

return [

    'pagger' => 30,

];