<?php

return [
    'sender'     => 'AZ Parts', // Mobily.ws Sender Name
    'mobile'     => 'amotorz', // Mobily.ws Account Mobile (Username)
    'password'   => 'amotorz977', // Mobily.ws Password
    'deleteKey'  => 541235, 
    'resultType' => 1,
    'viewResult' => 1, 
    'MsgID'      => rand(00000,99999), 
];